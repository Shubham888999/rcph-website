# Multi-Position Migration Dry Run Report

Project ID: rcph-admin
Execution timestamp: 2026-06-24T21:45:57.239Z
READ-ONLY DRY RUN. No Firestore writes were performed.

## Global readiness summary

- Ready for write phase: NO
- Total users: 10
- Approved eligible users: 10
- Excluded pending users: 0
- Excluded rejected users: 0
- Excluded unapproved users: 0
- Auto-migratable users: 1
- Blocked users: 9
- Global blockers: 6
- Warning users: 0
- Joint positions: 0
- Unknown position values: 16
- Duplicate/manual candidates: 0
- Orphan attendance rows: 10

## Blocking issues

- Test User2 (55gy6SLPI3R3U2yvOWxet5Xw20k1): Unknown or ambiguous legacy position value requires manual review.
- Daksh Karachiwala (L9FRTHx6IfMpHs52xZgXwFGXnTK2): Unknown or ambiguous legacy position value requires manual review.
- Sumit Chankhore (ML9IljWaELSWvgT8QlNO7PAMwgD2): Unknown or ambiguous legacy position value requires manual review.
- Test User (VaQWJG84YeOMjx8oqa8P5LSSrWw2): Two or more authenticated users share the same email address.; Unknown or ambiguous legacy position value requires manual review.
- Test User (b6WOZFoUKxgSsH3tLFGhaU70uh42): Two or more authenticated users share the same email address.; Unknown or ambiguous legacy position value requires manual review.
- SWARIT KAWALE (kLMLk9aa3sfmDy5UHUNivzSboe42): Unknown or ambiguous legacy position value requires manual review.
- Shivani Kulkarni (rgGX0FZyYiQB0XHQFxj4L0JByq72): Unknown or ambiguous legacy position value requires manual review.
- Tanishqa Khutwad (sksVGuQPvZO4yvMHVv4BnuOLaDT2): Unknown or ambiguous legacy position value requires manual review.
- Sneh Yajnik (zFG7Hr8AtzMkZcSDnMSw99QLq2x1): Unknown or ambiguous legacy position value requires manual review.
- roles/4HVIQFj2pjOHcRgxTncpMHnFKF23: roles/4HVIQFj2pjOHcRgxTncpMHnFKF23 references an approved role without a users document.
- roles/7kQSF1BSugZqsJXbbMZMceZOxwI3: roles/7kQSF1BSugZqsJXbbMZMceZOxwI3 references an approved role without a users document.
- roles/XpYMkuH1CdO9L9UssOMd8e7crcX2: roles/XpYMkuH1CdO9L9UssOMd8e7crcX2 references an approved role without a users document.
- roles/b0lrrOFEfHZQnYurVSR7DzbRCwj2: roles/b0lrrOFEfHZQnYurVSR7DzbRCwj2 references an approved role without a users document.
- roles/kEZNSVwd7RMFeAsNuVFVKW2O1ec2: roles/kEZNSVwd7RMFeAsNuVFVKW2O1ec2 references an approved role without a users document.
- roles/s51x56cpldaFUOMqekDxkAu0sed2: roles/s51x56cpldaFUOMqekDxkAu0sed2 references an approved role without a users document.

## Excluded accounts

- None.

## Users requiring review

- Test User2 (55gy6SLPI3R3U2yvOWxet5Xw20k1): role prospect, positions -
  - Blockers: Unknown or ambiguous legacy position value requires manual review.
- Daksh Karachiwala (L9FRTHx6IfMpHs52xZgXwFGXnTK2): role gbm, positions -
  - Blockers: Unknown or ambiguous legacy position value requires manual review.
- Sumit Chankhore (ML9IljWaELSWvgT8QlNO7PAMwgD2): role gbm, positions -
  - Blockers: Unknown or ambiguous legacy position value requires manual review.
- Test User (VaQWJG84YeOMjx8oqa8P5LSSrWw2): role prospect, positions -
  - Blockers: Two or more authenticated users share the same email address.; Unknown or ambiguous legacy position value requires manual review.
- Test User (b6WOZFoUKxgSsH3tLFGhaU70uh42): role gbm, positions -
  - Blockers: Two or more authenticated users share the same email address.; Unknown or ambiguous legacy position value requires manual review.
- SWARIT KAWALE (kLMLk9aa3sfmDy5UHUNivzSboe42): role gbm, positions -
  - Blockers: Unknown or ambiguous legacy position value requires manual review.
- Shivani Kulkarni (rgGX0FZyYiQB0XHQFxj4L0JByq72): role gbm, positions -
  - Blockers: Unknown or ambiguous legacy position value requires manual review.
- Tanishqa Khutwad (sksVGuQPvZO4yvMHVv4BnuOLaDT2): role gbm, positions -
  - Blockers: Unknown or ambiguous legacy position value requires manual review.
- Sneh Yajnik (zFG7Hr8AtzMkZcSDnMSw99QLq2x1): role gbm, positions -
  - Blockers: Unknown or ambiguous legacy position value requires manual review.

## Unknown legacy values

- users/55gy6SLPI3R3U2yvOWxet5Xw20k1 clubPosition: "Prospect" candidates: none (low)
- users/L9FRTHx6IfMpHs52xZgXwFGXnTK2 clubPosition: "Member" candidates: none (low)
- members/L9FRTHx6IfMpHs52xZgXwFGXnTK2 position: "Member" candidates: none (low)
- users/ML9IljWaELSWvgT8QlNO7PAMwgD2 clubPosition: "Member" candidates: none (low)
- members/ML9IljWaELSWvgT8QlNO7PAMwgD2 position: "Member" candidates: none (low)
- users/VaQWJG84YeOMjx8oqa8P5LSSrWw2 clubPosition: "Prospect" candidates: none (low)
- users/b6WOZFoUKxgSsH3tLFGhaU70uh42 clubPosition: "Member" candidates: none (low)
- members/b6WOZFoUKxgSsH3tLFGhaU70uh42 position: "Member" candidates: none (low)
- users/kLMLk9aa3sfmDy5UHUNivzSboe42 clubPosition: "Member" candidates: none (low)
- members/kLMLk9aa3sfmDy5UHUNivzSboe42 position: "Member" candidates: none (low)
- users/rgGX0FZyYiQB0XHQFxj4L0JByq72 clubPosition: "Member" candidates: none (low)
- members/rgGX0FZyYiQB0XHQFxj4L0JByq72 position: "Member" candidates: none (low)
- users/sksVGuQPvZO4yvMHVv4BnuOLaDT2 clubPosition: "Member" candidates: none (low)
- members/sksVGuQPvZO4yvMHVv4BnuOLaDT2 position: "Member" candidates: none (low)
- users/zFG7Hr8AtzMkZcSDnMSw99QLq2x1 clubPosition: "Member" candidates: none (low)
- members/zFG7Hr8AtzMkZcSDnMSw99QLq2x1 position: "Member" candidates: none (low)

## Proposed joint positions and holders

- None.

## Duplicate/manual row candidates

- None.

## Orphan attendance rows

- districtAttendance/2i6NuXE4zsR6D9TlbuCp5D4MKzx1: 0 historical fields
- districtAttendance/4HVIQFj2pjOHcRgxTncpMHnFKF23: 1 historical fields
- districtAttendance/HYjG5OOxHQZ40L0aJs3EeDdknJu1: 0 historical fields
- districtAttendance/XpYMkuH1CdO9L9UssOMd8e7crcX2: 1 historical fields
- districtAttendance/b0lrrOFEfHZQnYurVSR7DzbRCwj2: 1 historical fields
- districtAttendance/hwyFX9HrAWXDrJVL1k0aG8jrokm2: 0 historical fields
- districtAttendance/i9Og1FSEwuh7RLQ5aauQLqP71MI3: 0 historical fields
- districtAttendance/kEZNSVwd7RMFeAsNuVFVKW2O1ec2: 1 historical fields
- bodAttendance/2i6NuXE4zsR6D9TlbuCp5D4MKzx1: 0 historical fields
- bodAttendance/gts8l6Mq1QQ9asx2j2dfK43MgeM2: 0 historical fields

## Proposed record actions

- 55gy6SLPI3R3U2yvOWxet5Xw20k1: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none
- L9FRTHx6IfMpHs52xZgXwFGXnTK2: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none
- ML9IljWaELSWvgT8QlNO7PAMwgD2: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none
- VaQWJG84YeOMjx8oqa8P5LSSrWw2: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none
- b6WOZFoUKxgSsH3tLFGhaU70uh42: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none
- kLMLk9aa3sfmDy5UHUNivzSboe42: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none
- kzI1AS8V8ENFqu98mRpRqxYcT0D2: users=update, roles=update, members=create, bodMembers=none, attendance=create, districtAttendance=create, bodAttendance=none
- rgGX0FZyYiQB0XHQFxj4L0JByq72: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none
- sksVGuQPvZO4yvMHVv4BnuOLaDT2: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none
- zFG7Hr8AtzMkZcSDnMSw99QLq2x1: users=blocked, roles=blocked, members=blocked, bodMembers=blocked, attendance=none, districtAttendance=none, bodAttendance=none

## Recommended review steps

- Resolve every blocking issue before any write migration.
- Review unknown legacy values and choose canonical position keys manually.
- Confirm every joint-position assignment explicitly.
- Review duplicate/manual rows before merging or deactivating anything.
- Confirm orphan attendance rows should be preserved or linked manually.
- Do not proceed to a write migration without Shubham approval.

## Command

`node C:\Personal\Z folder\RCPH Website\functions\scripts\dry-run-position-migration.js --project rcph-admin --confirm-read-only`
